import React from 'react';
import Link from 'next/link';

interface DashboardProps {
  user: { name: string };
  stats: {
    progressPct: number;
    solvedQuestions: number;
    correctCount: number;
    wrongCount: number;
    completedTests: number;
    mistakesCount: number;
  };
  lastActiveBank?: { id: string; name: string; section: string };
}

export default function StudentDashboard({ user, stats, lastActiveBank }: DashboardProps) {
  const isNewUser = stats.solvedQuestions === 0;

  return (
    <div className="min-h-screen bg-nibras-bg text-nibras-beige dir-rtl p-6 font-arabic">
      {/* ترويسة الصفحة */}
      <header className="mb-8 flex justify-between items-center border-b border-gray-800 pb-4">
        <div>
          <h1 className="text-3xl font-bold text-nibras-gold">أهلاً بك، {user.name}</h1>
          <p className="text-nibras-muted text-sm mt-1">استعد للقدرات بثقة وتابع تقدمك اليومي.</p>
        </div>
        <Link href="/profile" className="px-4 py-2 bg-nibras-card hover:bg-gray-800 rounded-lg text-sm border border-gray-700">
          الملف الشخصي
        </Link>
      </header>

      {/* رسالة البداية من الصفر للمستخدم الجديد */}
      {isNewUser ? (
        <div className="bg-nibras-card border border-nibras-gold/30 rounded-xl p-8 text-center mb-8 shadow-lg">
          <h2 className="text-2xl font-bold text-nibras-gold mb-2">أهلاً بك في منصة نبراس القدرات!</h2>
          <p className="text-nibras-beige/80 mb-6">ابتدئ رحلة التميز الآن، لم تقم بإجراء أي تدريب بعد. خطوتك الأولى تبدأ من هنا.</p>
          <Link href="/quantitative" className="px-6 py-3 bg-nibras-gold text-nibras-bg font-bold rounded-lg hover:bg-nibras-goldHover transition">
            ابدأ أول تدريب لك الآن
          </Link>
        </div>
      ) : (
        /* قسم تابع من حيث توقفت */
        <div className="bg-nibras-card border border-gray-800 rounded-xl p-6 mb-8 flex justify-between items-center">
          <div>
            <span className="text-xs text-nibras-gold font-bold uppercase tracking-wider">استكمال التدريب</span>
            <h3 className="text-xl font-bold mt-1">{lastActiveBank?.name || "التدريب الحالي"}</h3>
            <p className="text-sm text-nibras-muted">القسم: {lastActiveBank?.section === 'QUANTITATIVE' ? 'الكمي' : 'اللفظي'}</p>
          </div>
          <Link href={`/${lastActiveBank?.section.toLowerCase()}/${lastActiveBank?.id}`} className="px-5 py-2.5 bg-nibras-gold text-nibras-bg font-bold rounded-lg hover:bg-nibras-goldHover transition">
            استكمال
          </Link>
        </div>
      )}

      {/* بطاقات الإحصائيات */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
        <StatCard title="نسبة الإنجاز" value={`${stats.progressPct}%`} highlight />
        <StatCard title="الأسئلة المحلولة" value={stats.solvedQuestions} />
        <StatCard title="إجابات صحيحة" value={stats.correctCount} color="text-green-400" />
        <StatCard title="إجابات خاطئة" value={stats.wrongCount} color="text-red-400" />
        <StatCard title="اختبارات مكتملة" value={stats.completedTests} />
        <StatCard title="قائمة الأخطاء" value={stats.mistakesCount} color="text-yellow-500" />
      </div>

      {/* أقسام الموقع السريعة */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <QuickAccessCard title="التدريب الكمي" desc="أسئلة ومسائل رياضية وتدريبات محاكية" href="/quantitative" />
        <QuickAccessCard title="التدريب اللفظي" desc="تناظر لفظي، إكمال جمل، واستيعاب المقروء" href="/verbal" />
        <QuickAccessCard title="الاختبارات المحاكية" desc="اختبارات بوقت محدد لمناظرة الاختبار الحقيقي" href="/tests" />
      </div>
    </div>
  );
}

function StatCard({ title, value, color = "text-nibras-beige", highlight = false }: any) {
  return (
    <div className={`p-4 rounded-xl border ${highlight ? 'border-nibras-gold bg-nibras-darkBrown/40' : 'border-gray-800 bg-nibras-card'}`}>
      <span className="text-xs text-nibras-muted block mb-1">{title}</span>
      <span className={`text-2xl font-bold ${color}`}>{value}</span>
    </div>
  );
}

function QuickAccessCard({ title, desc, href }: { title: string; desc: string; href: string }) {
  return (
    <Link href={href} className="p-6 bg-nibras-card border border-gray-800 hover:border-nibras-gold rounded-xl transition block group">
      <h3 className="text-xl font-bold text-nibras-gold group-hover:underline mb-2">{title}</h3>
      <p className="text-sm text-nibras-muted">{desc}</p>
    </Link>
  );
}
